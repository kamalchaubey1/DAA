#include <stdio.h>
#include <stdlib.h>
#include<time.h>
 
// Driver program
int main(void)
{
    // This program will create different sequence of 
    // random numbers on every program run 
 
    // Use current time as seed for random generator
    srand(time(0));
 
    for(int i = 0; i<4; i++){
    	for(int j=0; j<4;j++){
        printf("%d ", rand()%50);
    	}
    	printf("\n");
    }
    for(int i = 0; i<4; i++){
    	for(int j=0; j<4;j++){
        printf("%lf ", (double)(rand()%50)/100.0);
    	}
    	printf("\n");
    }

    return 0;
}
