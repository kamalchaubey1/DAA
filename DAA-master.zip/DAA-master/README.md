# DAA
This repository contains all the files related to the assignments taken during the course Design and Analysis of Algorithms.
The various assignments have been put in dedicated folders comprising of codes, input files and output files.
For each assignment we also had to prepare a report in IEEE format with details of the algorithm design, asymptotic analysis, running time graphs, experimental study and conclusion.
This report is prepared in LATEX. A report in pdf format for each assignment is also contained in the respective assignment folder.
